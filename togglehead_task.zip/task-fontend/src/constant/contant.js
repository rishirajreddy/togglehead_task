// export const baseUrl = "http://localhost:1333/api"
export const baseUrl = "http://localhost:4500/api";
export const baseUrlImage = "http://localhost:4500";
